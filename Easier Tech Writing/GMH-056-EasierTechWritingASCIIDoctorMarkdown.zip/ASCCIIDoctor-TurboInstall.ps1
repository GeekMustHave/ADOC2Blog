# Powershell Turbo Install for ASCIIDictor

# --- Example of Powershell script to step through the install process for ASCIIDoctor

#  Date      VBersion Author   Description
# 08/17/2017  2/1d      JHRS    Use version named with (-) only!!!!!!
#                               Added relative reference for all .\boxes commands ./.\boxes
# 08/14/2017  2.1c      JHRS    Decided to make Turbo instructions nad install
#                               Changed to Write-host to get color
#                               Changed names to be more WGET friendly
# 08/13/2017  2.1b      JHRS    Initial version of script

clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nGet Ruby installer EXE " | .\boxes -a hc -d ian_jones 
write-host "This will step through the installation and testing of all components of the ASCIIDoctor basic toolchain`n"
write-host "Each step will display the command that is being run.`n"
write-host "You can press <crtl>-c to abort the installation`n"
write-host "`nNOTE: This script may not run on all systems.  Those systems that are central managed are most likely to fail.`n" -ForegroundColor "yellow"
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nGet Ruby installer EXE " | .\boxes -a hc -d ian_jones 
write-host "`nwget https://github.com/oneclick/rubyinstaller2/releases/download/2.4.1-2/rubyinstaller-2.4.1-2-x64.exe -o RubyInstall.exe 
-UseBasicParsing`n
" -foreground "yellow"
pause
write-host "`nA green window will open and Ruby Installer downloaded.`n"
wget https://github.com/oneclick/rubyinstaller2/releases/download/2.4.1-2/rubyinstaller-2.4.1-2-x64.exe -o RubyInstall.exe -UseBasicParsing
write-host "`ndir *.exe`n" -foreground "Yellow"
dir *.exe
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nExecute Installer " | .\boxes -a hc -d ian_jones 
write-host `n".\rubyinstall.exe`n" -foreground "yellow"
pause
write-host "`nThe Ruby installer window will open, complete the installation and return`n"
.\RubyInstall.exe
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nVerify Ruby/Gem Install " | .\boxes -a hc -d ian_jones 
write-host "ruby --Version" -foreground "yellow"
ruby --version
write-host "`ngem --Version" -foreground "yellow"
gem --version
write-host "`n"
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nInstall / Verify ASCIIDoctor" | .\boxes -a hc -d ian_jones 
write-host "`ngem install asciidoctor`n" -foreground "yellow"
pause
gem install asciidoctor
write-host "`nasciidoctor -V`n" -foreground "yellow"
asciidoctor -V
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nDownload ADOC example" | .\boxes -a hc -d ian_jones 
write-host "`nwget https://GeekMustHave.com/Articles/EasierTechWriting/GMH-056-EasierTechnicalWriting-Markdown-ASCIIDoctor-WindowsInstallation.adoc `n   -o gmh_example.adoc -UseBasicParsing`n" -foreground "yellow"
wget https://GeekMustHave.com/Articles/EasierTechWriting/GMH-056-EasierTechnicalWriting-Markdown-ASCIIDoctor-WindowsInstallation.adoc -o gmh_example.adoc -UseBasicParsing
write-host "`ndir *.adoc`n" -foreground "yellow"
dir *.adoc
pause

clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nView ADOC example" | .\boxes -a hc -d ian_jones 
write-host "`nnotepad gmh_example.adoc`n" -foreground "yellow"
write-host "`nA notepad window will open, after you view file, close notepad`n"
pause
notepad gmh_example.adoc
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nTest ASCIIDoctor" | .\boxes -a hc -d ian_jones 
write-host "`nasciidoctor gmh_example.adoc`n" -foreground "yellow"
pause
asciidoctor gmh_example.adoc
write-host "`ndir *.html`n" -foreground "yellow"
dir *.html
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nView HTML Result" | .\boxes -a hc -d ian_jones 
write-host "`n.\gmh_example.html`n" -foreground "yellow"
write-host "`nA browser window will open with generated HTML, after viewing, close browser.`n"
pause
.\gmh_example.html 
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nInstall / Verify ASCIIDoctor-PDF" | .\boxes -a hc -d ian_jones 
write-host "`ngem install asciidoctor-pdf --pre`n" -foreground "yellow"
pause
gem install asciidoctor-pdf --pre
write-host "`nasciidoctor-pdf -V`n" -foreground "yellow"
asciidoctor-pdf -V
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nTest ASCIIDoctor-PDF" | .\boxes -a hc -d ian_jones 
write-host "`nasciidoctor-pdf gmh_example.adoc`n " -foreground "yellow"
pause
asciidoctor-pdf gmh_example.adoc 
write-host "`ndir *.pdf`n" -foreground "yellow"
dir *.pdf
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nView PDF result" | .\boxes -a hc -d ian_jones 
write-host "`n.\gmh_example.pdf`n " -foreground "yellow"
write-host "`nA PDF viewer will open, after viewing PDF, close PDF viewer.`n"
pause
.\gmh_example.pdf 
pause


clear-host
write-output "GeekMustHave `nASCIIDoctor Turbo Installation`nCompleted" | .\boxes -a hc -d ian_jones 
write-host "`nYou have completed the Installation of ASCIIDoctor Toolchain`n"
write-host "`nThe PDF file has some links to help you get started with ASCIIDoctor syntax.`n"
write-host "`nThis script can be downloaded from, look at the README file for instructions"
write-host "https://GeekMustHave.com/Articles/EasierTechWriting/ASCCIIDoctor-TurboInstall.zip`n" -foreground "yellow"
write-host "`nThe ADOC file example can be downloadd at"
write-host "https://GeekMustHave.com/Articles/EasierTechWriting/GMH-056-EasierTechnicalWriting-Markdown-ASCIIDoctor-WindowsInstallation.adoc`n" -foreground "Yellow"
write-host "`nMore goodies at my blog"
write-host "https://GeekMustHave.com`n" -ForegroundColor "yellow"
write-host "`nPlease consider Subscribing to my YouTube channel to let me know this was helpful."
write-host "https://www.youtube.com/channel/UChNSlqKgG8_l0h0C8vRLvbA`n" -ForegroundColor "yellow"
write-host "`nThank you."
