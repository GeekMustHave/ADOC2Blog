GeekMustHave - Easier Tech Writing - Windows installation

08/14/2017  Initial version of the instruction set created

Unzip this ZIP into a new empty directory.

Run the powershell script

1, (WindowsKey)-R
2. In the run winidw, type "powershell ASCIIDoctor-TurboInstall.ps1" and (Enter)

Enjoy.


GeekMustHave is a **Maker**, I build things, I help others to understand how to build things.

Visit my https://geekmusthave.com[ blog] for more goodies.

Please consider **Subscribing** to my https://www.youtube.com/channel/UChNSlqKgG8_l0h0C8vRLvbA[ YouTube Channel] to let me know if this has been helpful.

Your support is greatly appreciated.
